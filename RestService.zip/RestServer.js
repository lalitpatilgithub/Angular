var express = require('express');
var app = express();
var http = require('http');
var fs = require("fs");
var url = require("url")
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
app.use((req, res,next)=> {
  res.header('Access-Control-Allow-Origin', '*');
	res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
  next();
});

app.get('/listUsers', function (request, response) {
//http.createServer(function (request, response) {
	console.log('request');
	// Check if user requests /
	//if (request.url == '/listUsers') {
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       console.log( data );
       response.end( data);
       });
   /*} else {
		// Indicate that requested file was not found.
		response.writeHead(404);
		// And end request without sending any data.
		response.end();
	}
	}).listen(8888);*/
});
app.post('/subServ', function (request, response) {
console.log("hiiiiiiii");
     	var x= request.body.x;
	var y= request.body.y;
//	console.log(x);
//	console.log(y);
	var result = parseInt(x) - parseInt(y);
	response.json({'result':result});

});

app.post('/sub', function (request, response) {
	console.log("hiiiiiiii");
     	var x= request.body.x;
	var y= request.body.y;
	var result = parseInt(x) - parseInt(y);
	response.json({'result':result});

});

app.get('/add', function(request, response){
	var _get = url.parse(request.url,true).query;
	var x = _get['x'];
	var y = _get['y'];
	
	var result = parseInt(x) +parseInt(y);
	response.end(""+result);
});

var server = app.listen(8081, function () {

  var host = server.address().address;
  var port = server.address().port;

  console.log("Example app listening at http://%s:%s", host, port);


});
