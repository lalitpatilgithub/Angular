import { Component, AfterViewInit, ViewChild } from '@angular/core';
import { ChildComponent } from './child/child.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  title = 'child-parent-communication';
  messageFromChild : string;
  
  @ViewChild(ChildComponent,{static:false}) myChild;

  ngAfterViewInit() {
    this.messageFromChild = this.myChild.message;
  }
}
