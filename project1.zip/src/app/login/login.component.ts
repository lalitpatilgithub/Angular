import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { CustomNameValidator } from 'src/CustomNameValidator';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  constructor(private formbuilder: FormBuilder) {
    this.loginForm= this.formbuilder.group({
      userId : new FormControl(null, CustomNameValidator.validate),
      password : new FormControl(null)
    }
    );

  }

  ngOnInit() {
  }

  onSubmit(loginForm){
    alert(loginForm.userId);
  }
}
