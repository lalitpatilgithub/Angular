export class Product{

  name: string ;
  id: number ;

  constructor(name,id){
    this.name = name;
    this.id = id;
  }
}
