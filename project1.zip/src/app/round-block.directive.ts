import { Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appRoundBlock]'
})
export class RoundBlockDirective {

  constructor(private elementRef: ElementRef,  private renderer: Renderer2) { }

  ngOnInit(){
      this.renderer.setStyle(this.elementRef.nativeElement,'border-radius','30px');
  }

}
