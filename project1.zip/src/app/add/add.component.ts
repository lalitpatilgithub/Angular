import { Component, OnInit } from '@angular/core';
import { AddService } from '../add.service';
import { SubService } from '../sub.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  num1: number;
  num2: number;
  result: number;
  constructor(private addservice: AddService, private subService: SubService) {
    this.num1 = 0;
    this.num2 = 0;
    this.result = 0;


   }


  ngOnInit() {
  }

  doAddition(){
    //this.result = (this.num2 + this.num1);
   //this.result =  this.addservice.addition( this.num1 , this.num2);

   this.addservice.addition(this.num1, this.num2).subscribe(
      (response) => this.result=parseInt(response)


   );
  }

  doSubstraction(){
    this.subService.substraction(this.num1, this.num2).subscribe(
      (response) => this.result=parseInt(response)

   );
  }

}
