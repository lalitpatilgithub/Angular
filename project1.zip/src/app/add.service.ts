import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AddService {

  constructor(private httpClient: HttpClient) { }

  addition(num1: number, num2: number): Observable<any> {
    console.log('In Addition service');
    const url ='http://localhost:8081/add?x=' + num1 + '&y=' + num2;
    return this.httpClient.get(url).pipe(map(response => {
      console.log(response);
      return response.toString();
    }));
  }



}
