import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SubService {

  constructor(private httpClient: HttpClient) { }

  substraction( num1: number , num2: number): Observable<any>{
    console.log('In Sub service');
    const url ='http://localhost:8081/sub';
    var data = { 'x' : num1,'y': num2};
    return this.httpClient.post<any>(url,data).pipe(map(response => {
      console.log(response);
      return response.toString();
    }));
  }

}
