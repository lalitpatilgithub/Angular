import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products : Product[];
  userId : string;
  constructor(route : ActivatedRoute) {
   this.products =[ new Product('abc',100),
    new Product('xyz',200),
    new Product('lmn',300)
  ]
  }

  ngOnInit() {
  }

}
