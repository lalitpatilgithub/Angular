import { FormControl, FormControlName } from '@angular/forms';

export  class CustomNameValidator {
 static validate(userId: FormControl){
  let regx = /[A-Za-z]+/;
  return regx.test(userId.value) ? null: {
      validate:{
        valid: false
      }
  };

}

}
