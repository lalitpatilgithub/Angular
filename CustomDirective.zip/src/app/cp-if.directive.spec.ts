import { CpIfDirective } from './cp-if.directive';

describe('CpIfDirective', () => {
  it('should create an instance', () => {
    //const directive = new CpIfDirective();
    //expect(directive).toBeTruthy();
  });
});
