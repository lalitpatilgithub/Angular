import { CpLoopDirective } from './cp-loop.directive';

describe('CpLoopDirective', () => {
  it('should create an instance', () => {
    //const directive = new CpLoopDirective();
   // expect(directive).toBeTruthy();
  });
});
