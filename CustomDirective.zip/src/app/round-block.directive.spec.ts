import { RoundBlockDirective } from './round-block.directive';

describe('RoundBlockDirective', () => {
  it('should create an instance', () => {
   // const directive = new RoundBlockDirective();
   // expect(directive).toBeTruthy();
  });
});
