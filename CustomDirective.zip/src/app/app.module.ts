import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RoundBlockDirective } from './round-block.directive';
import { CpIfDirective } from './cp-if.directive';
import { CpLoopDirective } from './cp-loop.directive';

@NgModule({
  declarations: [
    AppComponent,
    RoundBlockDirective,
    CpIfDirective,
    CpLoopDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
